// Compare i-j-k, i-k-j and blocked GEMM, row-major FP64 matrices.
// Example:
//   cc -O3 -march=native -std=c11 -D_POSIX_C_SOURCE=200809L \
//      scripts/benchmark_c.c -lm -o bench_c && ./bench_c
// Benchmarks and checks printed at runtime; nothing is hard-coded.
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static double seconds(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

static void matmul_ijk(int n, const double *restrict a, const double *restrict b,
                       double *restrict c) {
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j) {
            double sum = 0.0;
            for (int k = 0; k < n; ++k) sum += a[i*n+k] * b[k*n+j];
            c[i*n+j] = sum;
        }
}

static void matmul_ikj(int n, const double *restrict a, const double *restrict b,
                       double *restrict c) {
    memset(c, 0, (size_t)n*n*sizeof(double));
    for (int i = 0; i < n; ++i)
        for (int k = 0; k < n; ++k) {
            const double aik = a[i*n+k];
            for (int j = 0; j < n; ++j) c[i*n+j] += aik*b[k*n+j];
        }
}

static void matmul_blocked(int n, int t, const double *restrict a,
                           const double *restrict b, double *restrict c) {
    memset(c, 0, (size_t)n*n*sizeof(double));
    // Supports any n; a tail block may be smaller than t.
    for (int ii=0; ii<n; ii+=t)
        for (int kk=0; kk<n; kk+=t)
            for (int jj=0; jj<n; jj+=t)
                for (int i=ii; i<n && i<ii+t; ++i)
                    for (int k=kk; k<n && k<kk+t; ++k) {
                        double aik=a[i*n+k];
                        for (int j=jj; j<n && j<jj+t; ++j)
                            c[i*n+j] += aik*b[k*n+j];
                    }
}

static void benchmark(const char *name, int n,
                      void (*impl)(int,const double*,const double*,double*),
                      const double *a, const double *b, double *c,
                      const double *reference) {
    impl(n,a,b,c); // warm-up
    double best = 1e100;
    for (int r=0; r<5; ++r) {
        double begin=seconds();
        impl(n,a,b,c);
        double dt=seconds()-begin;
        if (dt<best) best=dt;
    }
    double max_error=0.0;
    for (size_t i=0; i<(size_t)n*n; ++i) {
        double error=fabs(c[i]-reference[i]);
        if (error>max_error) max_error=error;
    }
    printf("%-12s %9.3f ms  %9.3f GFLOP/s  max_abs_diff %.3g\n",
           name, best*1e3, 2.0*n*n*n / best / 1e9, max_error);
}

static int tile = 32;
static void blocked_wrapper(int n, const double *a,const double *b,double *c) {
    matmul_blocked(n,tile,a,b,c);
}

int main(int argc,char **argv) {
    int n = argc>1 ? atoi(argv[1]) : 256;
    if (n<1 || n>4096) { fprintf(stderr,"Expected N in [1,4096]\n"); return 2; }
    size_t len=(size_t)n*n;
    double *a=malloc(len*sizeof(double)),*b=malloc(len*sizeof(double));
    double *c=malloc(len*sizeof(double)),*reference=malloc(len*sizeof(double));
    if (!a || !b || !c || !reference) { fprintf(stderr,"Allocation failure\n"); return 1; }
    for (size_t p=0; p<len; ++p) {
        a[p] = ((double)((p*17u)%223u)-111.0)/223.0;
        b[p] = ((double)((p*37u)%241u)-120.0)/241.0;
    }
    matmul_ijk(n,a,b,reference);
    benchmark("ijk",n,matmul_ijk,a,b,c,reference);
    benchmark("ikj",n,matmul_ikj,a,b,c,reference);
    benchmark("blocked T32",n,blocked_wrapper,a,b,c,reference);
    free(a);free(b);free(c);free(reference);
    return 0;
}
