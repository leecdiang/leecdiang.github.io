"""FP64 matrix multiplication: Python scalar loop vs NumPy BLAS.

Usage:
    OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 OMP_NUM_THREADS=1 \
      VECLIB_MAXIMUM_THREADS=1 python scripts/benchmark_python.py
"""

import time
import statistics
import numpy as np

N = 128
rng = np.random.default_rng(42)
A = rng.standard_normal((N, N)).astype(np.float64)
B = rng.standard_normal((N, N)).astype(np.float64)


def python_loop():
    C = np.zeros_like(A)
    for i in range(N):
        for j in range(N):
            acc = 0.0
            for k in range(N):
                acc += A[i, k] * B[k, j]
            C[i, j] = acc
    return C


def numpy_blas():
    return A @ B


def benchmark(fn, repeat):
    fn()
    samples = []
    for _ in range(repeat):
        t0 = time.perf_counter()
        fn()
        samples.append(time.perf_counter() - t0)
    return statistics.median(samples)


if __name__ == '__main__':
    np.testing.assert_allclose(python_loop(), numpy_blas(), rtol=1e-10, atol=1e-10)
    for name, fn, repeat in [('Python loop', python_loop, 3), ('NumPy @', numpy_blas, 50)]:
        t = benchmark(fn, repeat)
        gflops = (2 * N ** 3) / t / 1e9
        print(f'{name:12s}: {t * 1e3:9.3f} ms | {gflops:8.3f} GFLOP/s')
    print('NumPy configuration:')
    np.show_config()
