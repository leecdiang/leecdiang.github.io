---
title: "为什么我觉得 X86 指令集 就是一坨狗屎"
slug: why-x86-is-a-mess
permalink: 2026/11/03/why-x86-is-a-mess/
date: 2026-11-03 18:30:00
updated: 2026-11-03 18:30:00
categories:
  - 计算机体系结构
tags:
  - x86
  - ARM
  - RISC-V
  - 指令集
  - 计算机体系结构
description: "从不规则指令编码、历史兼容性和 x86S 的失败，谈 x86 的真实工程代价，以及世界转向多架构的可能。"
mathjax: true
---

假如你接手了一个迭代四十多年的 RTL 仓库，每次升级都不敢删除旧逻辑，状态机、旁路条件和兼容分支越堆越多，你会怎么评价它？

我大概会说：这玩意儿早该重构了。

x86 恰好就是计算机产业里一个极端成功、因而极端难以重构的例子。它诞生于 1978 年的 Intel 8086，后来装进了 PC、服务器、工作站，建立了规模惊人的软件生态。今天的高性能 x86 处理器早已不是四十年前那颗芯片，它们可以拥有宽大的乱序后端、复杂的分支预测、向量计算和先进封装。但在这些精致的工程之上，仍然压着一套漫长历史留下的架构契约。[S01](#x86-ref-S01) [S05](#x86-ref-S05)

最妙的是，连 Intel 都试过动这份契约。它在 2023 年提出精简 x86 的 **x86S**，后来却决定不再推进。2024 年，Intel 和 AMD 又联合产业伙伴组建了 x86 生态咨询组，准备一起协调这套 ISA 的未来。[S05](#x86-ref-S05) [S06](#x86-ref-S06)

标题骂得难听，观点其实很明确：**我反感的不是 x86 CPU 的性能，也不是设计它们的工程师，而是硬件为了延续旧软件而必须长期承担的架构负债。** 我想知道，这笔账到底有多大。如果有一天全球真的不再需要它，我们又能换回多少设计自由。

![过去的硬件遗产与新架构的想象性对照](/2026/11/03/why-x86-is-a-mess/assets/hero-legacy-to-future.png)

*题图：原创概念插画，左侧是不断堆叠的兼容性遗产，右侧代表重新组织计算平台的可能；并非真实芯片的内部照片。*

<!-- more -->

## 从四个字节开始，理解 x86 为什么难伺候

翻开 x86 指令手册，最让人头疼的不是指令数量，而是**连下一条指令从哪里开始，都要先解析当前指令**。

x86-64 的指令可以长 1 到 15 Byte。它可能带有传统前缀、REX 前缀，也可能采用 VEX、EVEX 等扩展编码；寻址与操作数又可能需要 ModR/M、SIB、位移量和立即数。APX 还引入了 REX2。字段的位置和长度由指令类别与执行模式决定。[S02](#x86-ref-S02)

AArch64 的 A64 指令则统一是 32 bit，也就是 4 Byte。处理器沿着指令流取出四个字节，天然就知道下一条从哪里开始。RISC-V 的基础指令为 32 bit，常见的 RV64GC 又引入 16 bit 压缩指令：需要判断 2 Byte 还是 4 Byte，但它从一开始就为这种长度变化留好了编码结构。严格说，RISC-V 规范还允许更长的格式，不能把整个 RISC-V 家族说成永远只有两种长度。[S03](#x86-ref-S03) [S04](#x86-ref-S04) [S18](#x86-ref-S18)

<!--FIG01-->

这张图不能解读成“x86 的解码器有 ARM 的十五倍大”。字节长度不是门数，也不是功耗。它指出的是一种非常具体的工程差别：A64 的指令边界由定长编码直接给出，x86 的长度、前缀和操作数解释则彼此纠缠。

让前端一次处理多条 x86 指令，难点就跟着出现了。前端从缓存拿到一批字节，要划分指令边界、处理跨边界指令，再识别编码与操作数。做得越宽，并行处理这些不规则边界的压力越大。现代 x86 核心当然有办法：长度预译码、复杂解码器、微操作缓存，以及不同实现各自积累的技巧。但这些技巧本身也需要设计、验证和维护。[S02](#x86-ref-S02)

### 一条漂亮的指令，四种要解释的东西

看一个小得不能再小的操作：将 `p` 指向的 64 位整数加一。我们只比较单线程普通读改写操作，不讨论并发原子性，也不依赖条件标志位的最终状态。

```c
#include <stdint.h>
void increment(uint64_t *p) {
    *p += 1;
}
```

x86-64 可以用一条合法的机器指令完成这件事：

```asm
add QWORD PTR [rdi], 1   ; 48 83 07 01
```

我用 GNU `as` 和 `objdump` 核对了这组机器码。它一共四个字节，已经把内存寻址、读改写操作和立即数塞进去了。但 `48` 是 REX.W，`83` 是操作码，`07` 是 ModR/M，`01` 才是真正要加的数。处理器必须知道这些字段如何相互约束，才能弄明白这条指令要求做什么。

<!--FIG02-->

同一操作若用 A64 的普通 load/store 指令表达，可以写成：

```asm
ldr x8, [x0]
add x8, x8, #1
str x8, [x0]
```

RISC-V RV64I 也很直白：

```asm
ld   t0, 0(a0)
addi t0, t0, 1
sd   t0, 0(a0)
```

这里反而是 x86 赢了：一条指令、四个字节；后两种示例各三条基础指令、十二个字节。编译器实际会根据上下文选择不同写法，RISC-V 的压缩扩展也可能进一步改变字节数。这个例子不适合拿来宣布谁更快，却能看清 CISC 的交换条件：**用更复杂的机器语义换取紧凑的代码表达。**

而且，x86 的一条机器指令并不保证在核心内部只是一项操作。复杂的内存操作可能被拆解成加载、运算、存储相关的内部操作。不同微架构如何拆解、融合、执行，没有统一答案。A64 和 RISC-V 的高性能核心同样可能采用内部操作、投机执行和复杂调度。[S10](#x86-ref-S10)

## 麻烦不只在译码器，还有那些舍不得删的历史

如果 x86 只是变长编码，我还不会用这么狠的标题。真正让人难受的，是从 8086、286、386 一路延伸过来的运行模式与架构状态。

早年的 16 位实模式、分段寻址、保护模式、32 位兼容性，再到后来的 x86-64 long mode，让 x86 形成了一张层层叠加的历史地图。x87 浮点栈、各代 SIMD 扩展、不同的前缀语义，又让这张地图不断向外扩张。注意，这不等于“Windows 11 现在还可以直接运行所有 DOS 程序”：操作系统能运行什么，与硬件保留了哪些历史机制，是两回事。[S05](#x86-ref-S05)

<!--FIG04-->

Intel 当年提出 x86S，理由已经够说明问题了：64 位操作系统成为主流后，一部分遗留模式在现代系统中几乎只用于启动过渡，值得考虑移除。它的草案想删掉部分 16/32 位特权与运行模式，同时**保留 long mode 下的 32 位应用兼容子模式**。也就是说，Intel 提议的都不是“立刻砸碎全部旧软件”，而是一次相当克制的清理。[S05](#x86-ref-S05)

可连这一步都没走成。Intel 最终宣布不继续推进 x86S，并强调继续维护软件兼容性。大约同一阶段，Intel、AMD 和产业伙伴开始通过 x86 生态咨询组讨论更一致的架构接口。[S05](#x86-ref-S05) [S06](#x86-ref-S06)

这件事非常能说明 x86 的处境：旧功能在工程上可能没那么值得留，在商业上却很难放弃。某家公司的固件、某套企业虚拟化环境、某个靠老二进制维生的业务，只要还在，厂商就必须认真考虑它。存量软件从外部给芯片设计施加约束，硬件也不能简单地宣布“从今天起不兼容了”。

你可以在 RTL 里清掉一段死逻辑，却没法轻易清掉全球用户对一条 ISA 的预期。

## Intel 和 AMD 到底为这套包袱花了多少钱？

这是我最想看到具体数字的地方，也是最容易被技术评论写歪的地方。

Intel 的 2025 年报写明，当年的研发费用为 **138 亿美元**；AMD 的同期研发费用为 **80.91 亿美元**。加起来约 **218.91 亿美元**。数字相当惊人，不过这笔钱横跨了制程、封装、CPU、GPU、AI 加速器、FPGA、软件以及其他研究方向。财报没有把“维护 x86 旧模式、旧指令和相关验证”单独拆出来。[S07](#x86-ref-S07) [S08](#x86-ref-S08)

<!--FIG05-->

所以，谁要是拿这 219 亿美元说“都浪费在 x86 上了”，我反而不会相信。Intel 的工艺节点与晶圆厂问题，AMD 的 GPU、AI 和软件投入，显然不能直接扣到 x86 ISA 的头上。

不过，有些成本确实随着这套架构一直存在，而且能明确指出工作发生在哪儿：

- **指令前端。** 处理变长指令、前缀、跨界和罕见编码，还要在高吞吐、低延迟与低功耗之间做设计选择。
- **功能验证。** 旧模式、异常、特权切换、虚拟化、指令扩展之间的交互，需要规格、测试与回归；软件可以观察到的行为，不能随便改。
- **固件与操作系统。** 启动路径、特性枚举、微码更新、ABI 及虚拟化兼容，都需要厂商和系统软件合作。
- **产品迭代。** 一部分工程人力持续用于确保“旧程序还是对的”，而不是完全投入新指令、新执行模型或更简单的硬件接口。

这些是可识别的工程负担，但公开信息不足以给它们合计出可信的金额。即便某家厂商明天宣布采用 A64，做新芯片仍然需要微架构、工具链、验证和操作系统团队；也不能把从前的所有前端成本都当作可节约项。

### 功耗上倒是有一份值得看的实验

2016 年的 USENIX CoolDC 论文试着专门激活 x86-64 的解码路径。在微基准超出已解码指令缓存容量的条件下，作者通过封装 RAPL 功耗测量与回归模型，估计解码器消耗了封装功耗的 **3%–10%**。[S09](#x86-ref-S09)

<!--FIG06-->

我喜欢这份实验，是因为它真的把问题推进到了测量层面。可它并没有证明“换成 ARM 就立刻省下 10% 的整机功耗”：这是一项 2016 年特定平台、特定工作负载下的估计范围，也没有进行保持核心其余设计不变的跨 ISA 替换实验。

从工程视角看，我更在意被这份规范占据的设计空间。假如少了一批旧运行模式和不规则指令，前端能简化到什么程度？验证矩阵能缩小多少？是否能用更简单的规则提高取指和解码吞吐？答案得靠具体设计和测量，而不是靠 ISA 名字猜。

## 那 ARM 为什么看起来那么香？

Apple Silicon 的出现，显然让这件事有了很强的现实感。Apple 在 2020 年正式启动 Mac 从 Intel 到自研 Arm 架构芯片的迁移，连编译器、通用二进制和翻译层的过渡方案都一起准备好了。用户后来看到的则是出色的性能、能效和整机体验。云服务器也已经可以在 x86 以外选择 Arm 平台。[S20](#x86-ref-S20)

但这不能导出一个漂亮的“RISC 天然比 CISC 省电”定理。Emily Blem 等人在《ISA Wars》中比较过 ARM、MIPS 与 x86 平台，发现它们代表的是不同的工程设计点，不能单凭 RISC/CISC 分类预测性能与能效。[S10](#x86-ref-S10)

现代 CPU 的电和晶体管大量花在缓存、预测、执行单元、乱序窗口、内存系统和互连上。制程、频率、电压、核心规模、操作系统策略、内存与 SoC 集成方式都能改写最终结果。Apple 的优秀产品也包括这些因素，不能把功劳全给 A64 的 32 位定长编码。

<!--FIG03-->

AArch64 自身当然也不是一本永远保持极简的教科书。SVE、SME、虚拟化、安全特性和各种系统寄存器都在扩充它的架构规模。RISC-V 也并非不用付扩展兼容的账；模块化让它易于定制，同时要求软件与硬件对支持哪些扩展达成一致。[S18](#x86-ref-S18) [S19](#x86-ref-S19)

但我仍觉得 A64 和 RISC-V 更适合作为未来新增设计的起点：它们有机会把历史功能取舍写进架构边界，而不是把四十年前的决定都视为理所当然。

## 假设全世界约好不再用 x86，会怎么样？

我当然希望看到这个平行宇宙。全世界的操作系统、编译器、云厂商、游戏工作室、芯片公司一起宣布：以后主力通用计算转向 AArch64 和成熟的 RISC-V 配置，新软件默认多架构发布，x86 留在隔离的兼容环境里慢慢退役。

最令人兴奋的并不是明天电脑突然快一倍，而是**整个产业终于可以重新谈判软硬件之间的接口**。CPU 公司不必把每一项新设计都安放在同一套历史状态之上，软件开发者也不用把 x86-64 当成唯一的桌面和服务器目标。硬件市场会更开放：Arm 芯片设计者围绕各自的 SoC 目标优化，RISC-V 实现者则可以在开放 ISA 的基础上探索新的微架构与专用扩展。[S13](#x86-ref-S13)

这里也有一个微妙的选择：如果目标是摆脱架构锁定，**“全世界统一改用 Arm”并不等于最自由的结局**。Arm 的架构与核心 IP 有商业授权模式，RISC-V 的基础 ISA 与标准扩展则是开放、免版税规范。开放 ISA 不等于免费获得先进 CPU 核心、EDA、验证 IP 或量产能力，但它把指令集本身从专有授权中独立了出来。[S13](#x86-ref-S13) [S17](#x86-ref-S17)

RISC-V 眼下也没有成熟到能直接接管全球的高端 PC。2026 年一项面向实际硬件与软件栈的研究指出，现有实现的性能与系统集成水平仍然参差，尤其在通用高性能领域还需要继续追赶。[S21](#x86-ref-S21) 我愿意看到更多 RISC-V 方案进场，但不会把一张开放 ISA 规范误当成已经完工的桌面平台。

问题在于，全球迁移远远不只是给 GCC 或 Clang 换一个编译参数。

Windows on Arm 已经能通过 Prism 翻译运行不少 x86/x64 用户态程序，但微软明确说明：**内核驱动不能靠这种翻译运行，必须提供原生 Arm64 版本。** 游戏里的反作弊、专业设备驱动、闭源插件、企业虚拟机镜像、特定 ISA 的手写汇编和性能库，都可能成为真正的障碍。[S14](#x86-ref-S14)

<!--FIG07-->

Apple 给出了一条现实路线。它在 2020 年开启 Mac 向 Apple Silicon 的转换，用 Rosetta 为 x86-64 应用提供过渡。到 2026 年 9 月，Apple 已明确宣布 macOS 27 是通用 Rosetta 支持的最后一个大版本；未来只为某些依赖 Intel 框架的老游戏保留有限支持。[S11](#x86-ref-S11) [S12](#x86-ref-S12)

这说明迁移可以做成，也说明迁移需要持续多年。Apple 能控制硬件、操作系统和软件分发；企业机房、DIY PC、科研设备、工业控制器与游戏生态则远比一条产品线分散。全球协同可以减少重复适配，却不能消灭每一个闭源程序和外设驱动的重写成本。

所以我想象的转型并不是“明天全网停机，后天统一换 ARM”。更合理的路线是：软件在 x86-64、AArch64 和 RISC-V 上都能构建与自动测试，主流组件维护跨架构基线；新项目尽量避免绑定某一家的 SIMD intrinsic 或二进制插件；硬件厂商则提供长期、可验证的驱动与系统接口。闭源遗留负载继续放在翻译器或老平台上，直到它们有足够的理由迁移。

这条路不必从说服 Intel 和 AMD 开始。先让软件不再把 x86 当成唯一默认平台，芯片厂商才有足够多的客户愿意试新架构。

## 我真正想摆脱的，是四十年前的一次选择权

承认 x86 的成功很容易。今天最强的 x86 处理器里面，有大量值得学习的微架构设计；它们能把如此复杂的外部指令集执行得这么快，本身就是工程能力的证明。

可工程能力越强，我越觉得可惜。如此多优秀的设计人员，需要反复确认那些古老而微妙的架构行为仍然正确；同样的创造力，本来也可以用来探索更干净的软硬件接口。

有人会说，能跑旧程序就是实打实的价值。没错。兼容性曾让个人计算机产业快速扩张，如今又让许多公司不必为重写系统付账。只是这笔账没有消失，它被摊到了之后一代又一代的芯片和开发工具里。谁先放弃兼容，谁就要替整个软件世界垫付迁移成本；谁继续兼容，谁就能留住客户。这种局面靠任何一家公司的勇气都很难打破。

我希望有一天，开发者买一颗新的高性能 CPU，不必先关心它如何假装理解 1978 年的世界。Intel 和 AMD 也可以在更干净的架构上竞争缓存、分支预测、执行宽度和计算单元，Arm 和 RISC-V 则继续把新的设计者带进来。

到那时，我大概就不会再说 x86 是一坨狗屎了。它会变成一段很精彩、也终于可以放进博物馆的计算机历史。

---

## 资料来源与图表口径

下列链接是本篇写作与图表的数据来源。文中所有 2025 年财务数据均为公司披露的 **总研发费用**；2016 年解码器功耗数字是有条件的研究结果；没有用未经验证的数据拼出“x86 的总浪费额”。

1. <span id="x86-ref-S01"></span> **[S01]** [Intel：The Intel 8086 and the IBM PC](https://www.intel.com/content/www/us/en/history/virtual-vault/articles/the-8086-and-the-ibm-pc.html)，1978 年 8086 历史及软件生态起点。
2. <span id="x86-ref-S02"></span> **[S02]** [Intel XED 文档](https://github.com/intelxed/xed/blob/main/docsrc/xed-doc-top.txt)，x86 指令 1–15 Byte 与前缀/字段格式。
3. <span id="x86-ref-S03"></span> **[S03]** [Arm：The A64 ISA and Compilers](https://developer.arm.com/community/arm-community-blogs/b/architectures-and-processors-blog/posts/the-a64-isa-and-compilers)，A64 的 32-bit 定长编码。
4. <span id="x86-ref-S04"></span> **[S04]** [RISC-V Unprivileged ISA：C Extension](https://docs.riscv.org/reference/isa/v20260120/unpriv/c-st-ext.html)，RVC 的 16-bit 压缩指令。
5. <span id="x86-ref-S05"></span> **[S05]** [Intel：Envisioning a Simplified Intel Architecture](https://www.intel.com/content/www/us/en/developer/articles/technical/envisioning-future-simplified-architecture.html)，x86S 提案及官方停止推进声明。
6. <span id="x86-ref-S06"></span> **[S06]** [Intel / AMD：x86 Ecosystem Advisory Group](https://newsroom.intel.com/corporate/october-2024-intel-news)，2024 年 10 月公告。
7. <span id="x86-ref-S07"></span> **[S07]** [Intel 2025 Form 10-K](https://www.intc.com/filings-reports/annual-reports/content/0000050863-26-000011/intc-20251227.htm)，2025 总研发 13.8B 美元。
8. <span id="x86-ref-S08"></span> **[S08]** [AMD 2025 Form 10-K](https://ir.amd.com/financial-information/sec-filings/content/0000002488-26-000018/amd-20251227.htm)，2025 总研发 8.091B 美元。
9. <span id="x86-ref-S09"></span> **[S09]** [Hirki et al., CoolDC/USENIX 2016](https://www.usenix.org/conference/cooldc16/workshop-program/presentation/hirki)，解码器封装功耗占比估计 3%–10%，仅在特定微基准条件下。
10. <span id="x86-ref-S10"></span> **[S10]** [Blem et al., *ISA Wars*, ACM TOCS (2015)](https://doi.org/10.1145/2699682)，RISC/CISC 与能效不能简单划等号。
11. <span id="x86-ref-S11"></span> **[S11]** [Apple Developer，2026-09-01：Upcoming changes to Rosetta support](https://developer.apple.com/news/?id=w5ngl9k2)，Rosetta 通用支持的结束安排。
12. <span id="x86-ref-S12"></span> **[S12]** [Apple：About the Rosetta translation environment](https://developer.apple.com/documentation/apple-silicon/about-the-rosetta-translation-environment)，翻译层能力与限制。
13. <span id="x86-ref-S13"></span> **[S13]** [RISC-V International：About RISC-V](https://riscv.org/about/)，开放 ISA 与商业实现的区别。
14. <span id="x86-ref-S14"></span> **[S14]** [Microsoft Learn：How emulation works on Arm](https://learn.microsoft.com/en-us/windows/arm/apps-on-arm-x86-emulation)，Prism 与用户态/内核态的兼容边界。
15. <span id="x86-ref-S15"></span> **[S15]** [AMD 2003–2004 Annual Report](https://ir.amd.com/financial-information/sec-filings/content/0001193125-04-037179/d10k.htm)，2003 年 AMD64 / Opteron 的历史。
16. <span id="x86-ref-S16"></span> **[S16]** [Intel Microprocessor Quick Reference](https://www.intel.com/pressroom/kits/quickrefyr.htm)，8086 / 386 发布年份。

17. <span id="x86-ref-S17"></span> **[S17]** [Arm：Architecture](https://www.arm.com/architecture)，Arm ISA 授权模式。
18. <span id="x86-ref-S18"></span> **[S18]** [RISC-V Ratified ISA：Introduction](https://docs.riscv.org/reference/isa/v20240411/unpriv/intro.html)，RISC-V 基本指令长度与扩展方式。
19. <span id="x86-ref-S19"></span> **[S19]** [RISC-V Profiles：Introduction](https://docs.riscv.org/reference/rva20-rvi20-rva22/intro.html)，扩展碎片化与 profile 的动机。

20. <span id="x86-ref-S20"></span> **[S20]** [Apple Newsroom：Mac transition to Apple silicon, 2020-06-22](https://www.apple.com/newsroom/2020/06/apple-announces-mac-transition-to-apple-silicon/)，正式迁移与 Universal 2/Rosetta 2 方案。
21. <span id="x86-ref-S21"></span> **[S21]** [IEEE ETS 2026：A real opportunity or still a promise?](https://ieeexplore.ieee.org/abstract/document/11591831)，RISC-V 现实软硬件成熟度研究。

*图 1–7 为依据公开资料或明确假设制作的原创 SVG 图表，附带可复算数据和脚本。题图为概念性生成插画，不能当作设备实拍。资料检索日期：2026 年 11 月 3 日。*
