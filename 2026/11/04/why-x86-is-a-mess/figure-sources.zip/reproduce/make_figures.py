#!/usr/bin/env python3
"""Rebuild the article's original, theme-aware scientific SVG figures.

The chart grammar is adapted from leecdiang.com's film-emulation-pipelines
reproduce/make_theme_figures.py: 800-unit canvas, v-ink/v-sub/v-grid classes,
theme variables, restrained color, and source-specific annotations.
This script uses no network and creates NO experimental benchmark results.
"""
from pathlib import Path
import csv, html, re, json
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'assets'
OUT.mkdir(parents=True, exist_ok=True)
INK='v-ink'; SUB='v-sub'; MUTED='v-muted'; GRID='v-grid'
BLUE='var(--chart-blue)'; TEAL='var(--chart-teal)'; AMBER='var(--chart-amber)'; RED='var(--chart-red)'

def esc(s): return html.escape(str(s),quote=True)
def t(x,y,s,sz=14,cls=INK,anchor='start',weight=None):
    w='' if not weight else f' font-weight="{weight}"'
    return f'<text x="{x}" y="{y}" font-size="{sz}" class="{cls}" text-anchor="{anchor}"{w}>{esc(s)}</text>'
def lines(x,y,ss,sz=13,cls=SUB,dy=20,anchor='start'):
    return ''.join(t(x,y+i*dy,s,sz,cls,anchor) for i,s in enumerate(ss))
def rect(x,y,w,h,color=BLUE,round=10,fill='var(--surface-card)',stroke_width=1.6):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{round}" fill="{fill}" stroke="{color}" stroke-width="{stroke_width}"/>'
def path(d,c=BLUE,w=2.4,fill='none',dash=None):
    sd = f' stroke-dasharray="{dash}"' if dash else ''
    return f'<path d="{d}" stroke="{c}" stroke-width="{w}" fill="{fill}" stroke-linecap="round" stroke-linejoin="round"{sd}/>'
def dot(x,y,c=BLUE,r=6): return f'<circle cx="{x}" cy="{y}" r="{r}" fill="{c}"/>'
def arrow(x1,y1,x2,y2,c=BLUE):
    return path(f'M{x1} {y1} L{x2-8} {y2}',c,2)+path(f'M{x2-13} {y2-6} L{x2-6} {y2} L{x2-13} {y2+6}',c,2)
def svg(body,title,h=440):
    return f'<svg xmlns="http://www.w3.org/2000/svg" role="img" aria-label="{esc(title)}" viewBox="0 0 800 {h}">\n'+body+'\n</svg>\n'
def save(name,markup):
    p=OUT/name
    p.write_text(markup,encoding='utf-8')
    return p

# Fig 1: spec-confirmed supported instruction sizes, not a gate-count ratio.
b=t(25,38,'指令边界有多难找？',23,weight='650')+t(26,65,'按公开 ISA 规范绘制；字节长度不能直接当作硬件面积。',13,SUB)
start,end=176,754
X=lambda n: start+(n/16)*(end-start)
for n in [0,2,4,6,8,10,12,14,16]:
    x=round(X(n),1)
    b+=path(f'M{x} 107 V338','var(--divider)',1,dash='3 6')+t(x,365,str(n),12,MUTED,'middle')
b+=t(466,395,'单条机器指令的编码长度（Byte）',14,SUB,'middle')
for y,label in [(151,'x86-64'),(238,'AArch64 / A64'),(324,'RISC-V · RV64GC')]:
    b+=t(24,y,label,16,INK)
b+=path(f'M{X(1):.1f} 144 H{X(15):.1f}',RED,12)+dot(X(1),144,RED,6)+dot(X(15),144,RED,6)
b+=t(X(1)-3,119,'1 B',13,RED if False else SUB,'middle')+t(X(15),119,'15 B',13,SUB,'middle')
b+=path(f'M{X(4)-8:.1f} 229 H{X(4)+8:.1f}',BLUE,10)+dot(X(4),229,BLUE,7)+t(X(4),206,'固定 4 B',13,SUB,'middle')
b+=dot(X(2),316,TEAL,7)+dot(X(4),316,TEAL,7)+path(f'M{X(2):.1f} 316 H{X(4):.1f}',TEAL,3,dash='4 6')
b+=t(X(2),293,'2 B',13,SUB,'middle')+t(X(4),293,'4 B',13,SUB,'middle')
b+=t(26,424,'RV64GC 以 16/32 bit 常见指令为主；RISC-V 通用编码机制还预留更长格式。',12,SUB)
save('fig01_instruction_lengths.svg',svg(b,'x86-64、A64 和 RV64GC 的指令编码长度范围',450))

# Fig 2: exact x86 bytes verified through GNU as + objdump in delivery prep.
b=t(26,37,'一条 64 位内存加法，里面藏着什么？',22,weight='650')+t(26,63,'手工挑选的一条合法 x86-64 指令；不是编译器对 C 函数的唯一输出。',12,SUB)
parts=[('48','REX.W','操作数 64 bit',TEAL),('83','Opcode','组操作码',BLUE),('07','ModR/M','[rdi] 与 ADD',AMBER),('01','imm8','立即数 +1',RED)]
for i,(hx,name,desc,color) in enumerate(parts):
    xx=24+i*196
    b+=rect(xx,96,171,124,color,10)
    b+=t(xx+85.5,136,hx,30,INK,'middle','650')+t(xx+85.5,168,name,15,SUB,'middle')+t(xx+85.5,198,desc,12,SUB,'middle')
b+=t(25,259,'ADD QWORD PTR [RDI], 1',20,INK,weight='600')
b+=t(25,291,'机器码：48 83 07 01 · 合计 4 Byte',14,SUB)
b+=path('M25 320 H772','var(--divider)',1.2)
b+=t(25,359,'真实的 x86 编码还可能涉及：',15,INK)
b+=t(25,386,'Legacy prefix / REX2 / VEX / EVEX · ModR/M · SIB · displacement · immediate',13,SUB)
b+=t(25,418,'字段是否存在、占几字节，取决于具体指令、寻址方式和模式。',13,SUB)
save('fig02_x86_bytes.svg',svg(b,'一条x86-64内存加法的四个编码字节',445))

# Fig 3: qualitative architecture pipeline with common back-end.
b=t(24,38,'前端先把“语言”翻译成能执行的动作',22,weight='650')+t(24,64,'功能示意，不对应任何特定芯片的门级结构、流水级数或解码宽度。',12,SUB)
rows=[('x86-64',119,RED,['取指 / 边界识别','前缀与模式解释','解码 / 生成 µops','重命名与乱序执行']),
      ('A64 / RV64',240,TEAL,['取指 / 已知边界','字段解码','内部操作生成','重命名与乱序执行'])]
for name,y,c,stages in rows:
    b+=t(24,y-10,name,17,INK,weight='600')
    for i,s in enumerate(stages):
        x=24+i*195
        b+=rect(x,y,170,70,c,10)
        b+=t(x+85,y+41,s,13,INK,'middle')
        if i<3:b+=arrow(x+172,y+35,x+193,y+35,c)
b+=rect(24,346,752,65,AMBER,8,fill='var(--surface-card)')
b+=t(400,372,'共同的难题：预测分支、调度、缓存、向量单元、内存一致性',14,INK,'middle')
b+=t(400,398,'简单的外部 ISA 不等于简单的高性能 CPU。',12,SUB,'middle')
save('fig03_frontend_paths.svg',svg(b,'x86与A64 RISC-V前端解码以及共有的后端复杂度',440))

# Fig 4: timeline, faithfully sourced and not claiming x86S shipped.
b=t(24,39,'半个世纪里，x86 是怎样长成现在这样的',21,weight='650')+t(24,66,'架构与生态事件时间线；只选与兼容性讨论有关的节点。',12,SUB)
pts=[(1978,'8086','16 位起点'),(1985,'80386','32 位扩展'),(2003,'AMD64','x86-64 扩展'),(2023,'x86S','Intel 提案'),(2024,'x86S','不再推进')]
X=lambda idx: [70,235,407,580,748][idx]
b+=path('M70 241 H748',BLUE,3)
for i,(year,main,minor) in enumerate(pts):
    x=X(i)
    y=127 if i%2==0 else 294
    b+=dot(x,241,RED if i==4 else TEAL,7)
    if i%2==0:
        b+=path(f'M{x} 236 V181',TEAL,2)
        b+=t(x,120,str(year),16,INK,'middle','600')+t(x,144,main,14,SUB,'middle')+t(x,164,minor,12,SUB,'middle')
    else:
        b+=path(f'M{x} 248 V288',TEAL,2)
        b+=t(x,314,str(year),16,INK,'middle','600')+t(x,337,main,14,SUB,'middle')+t(x,358,minor,12,SUB,'middle')
b+=t(24,399,'2024：Intel / AMD 成立 x86 生态咨询组。节点等距排列，不按时间间隔缩放。',13,SUB)
save('fig04_x86_timeline.svg',svg(b,'x86从8086到Intel停止推进x86S的时间线',437))

# Fig 5: corporate R&D expenditures, not a measure of legacy costs.
with (ROOT/'data'/'rd_2025.csv').open(encoding='utf-8') as f:
    data=list(csv.DictReader(f))
b=t(24,40,'2025 年 Intel / AMD 花了多少钱做研发？',22,weight='650')+t(24,67,'公司总研发费用（US$ billion），不能当成“x86 兼容性维护费”。',13,SUB)
x0,x1=170,724
X=lambda v:x0+v/16*(x1-x0)
for n in [0,4,8,12,16]:
    x=X(n)
    b+=path(f'M{x:.1f} 110 V317','var(--divider)',1,dash='3 6')+t(round(x,1),341,str(n),13,MUTED,'middle')
for i,d in enumerate(data):
    y=147+i*115
    n=float(d['rd_usd_billion']); c=BLUE if i==0 else TEAL
    b+=t(24,y+22,d['company'],19,INK,weight='650')
    b+=f'<rect x="{x0}" y="{y-6}" width="{X(n)-x0:.2f}" height="45" rx="5" fill="{c}"/>'
    b+=t(X(n)+12,y+22,f'{n:.2f}',17,INK)
b+=t(24,391,'合计 21.89 B 美元；官方财报没有把其中的 x86 兼容性维护成本单独披露。',12,SUB)
save('fig05_rd_spend.svg',svg(b,'2025年Intel和AMD公司总研发费用，非x86维护费用',420))

# Fig 6: empirically measured conditional decoder package power.
b=t(24,39,'x86 解码器到底吃多少电？有一份实测',21,weight='650')+t(24,66,'USENIX CoolDC 2016：针对解码路径的微基准与 RAPL 回归估计。',12,SUB)
b+=t(24,122,'0%',14,SUB)+t(704,122,'100%',14,SUB)
x0,x1=44,754
for tick in [0,10,20,40,60,80,100]:
    x=x0+(x1-x0)*tick/100
    b+=path(f'M{x:.1f} 151 V256','var(--divider)',1,dash='3 5')
    b+=t(round(x,1),278,str(tick),11,MUTED,'middle')
b+=f'<rect x="{x0}" y="{180}" width="{x1-x0}" height="44" rx="7" fill="var(--divider)" opacity="0.6"/>'
low=x0+(x1-x0)*.03; high=x0+(x1-x0)*.10
b+=f'<rect x="{low:.2f}" y="{174}" width="{high-low:.2f}" height="56" rx="4" fill="{RED}"/>'
b+=t(low-1,162,'3%',14,INK,'middle')+t(high,162,'10%',14,INK,'middle')
b+=rect(24,322,752,84,AMBER,8)
b+=lines(41,349,['触发条件：译码后的指令缓存容量被超过','含义：这是一项历史实验的条件性范围，不能推算现代 CPU 或切换 ISA 后的省电比例。'],13,SUB,30)
save('fig06_decoder_power.svg',svg(b,'2016年解码器在特定微基准中占封装功耗3到10个百分点的估计',438))

# Fig 7: migration matrix, no implied numeric costs.
b=t(24,37,'如果明天停止发布 x86 新芯片，谁需要做什么？',20,weight='650')+t(24,63,'全球迁移的工作分散在整个软件供应链；下面是任务分类，不是成本估算。',12,SUB)
cols=[24,212,407,604]
head=['原有资产','可以直接迁移的部分','最难补的缺口','承担主体']
for x,s in zip(cols,head): b+=t(x,102,s,13,INK,weight='650')
items=[('开源软件 / CLI','再编译、跑测试','汇编优化 / SIMD','维护者 / CI'),('桌面应用','原生构建 + 翻译层','插件 / 二进制依赖','厂商 / 用户'),('操作系统 / 设备','多架构内核 / 驱动','固件 / 外设 / 安全驱动','OEM / 芯片厂'),('云与企业业务','容器多架构镜像','虚拟机镜像 / 闭源软件','云厂 / IT 团队'),('科研与性能库','编译器和框架已有基础','逐平台算子调优','工具链 / 开发者')]
for i,row in enumerate(items):
    y=123+i*55
    b+=f'<rect x="22" y="{y}" width="756" height="50" rx="7" fill="var(--surface-card)" stroke="var(--divider)" stroke-width="1"/>'
    for j,(x,s) in enumerate(zip(cols,row)):
        b+=t(x+8,y+30,s,13,INK if j==0 else SUB,weight='600' if j==0 else None)
b+=t(24,432,'示意图：没有把工作项做成“难度分数”，避免编造可比较的迁移成本。',12,SUB)
save('fig07_migration_tasks.svg',svg(b,'全球从x86迁移所涉及的多架构软件工程任务',450))

print('Generated 7 theme-aware SVG figures in',OUT)
