from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
template = (root / 'reproduce/article_template.md').read_text(encoding='utf-8')
def inline_figure(match):
    return (root / 'assets' / match[1]).read_text(encoding='utf-8').strip()
article = re.sub(r'\{\{SVG:([a-z0-9_-]+\.svg)\}\}', inline_figure, template)
(root / 'article.md').write_text(article, encoding='utf-8')
