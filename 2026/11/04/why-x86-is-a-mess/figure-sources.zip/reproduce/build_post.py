#!/usr/bin/env python3
"""Assemble theme-compatible Hexo Markdown with inline research SVG charts."""
from pathlib import Path
import re,hashlib,json,html
ROOT=Path(__file__).resolve().parents[1]
TEMPLATE=(ROOT/'reproduce'/'article_template.md').read_text(encoding='utf-8')
CHARTS={
 '01':('fig01_instruction_lengths.svg','按 Intel XED、Arm 官方文档与 RISC-V 规范绘制的指令长度。x86 为定义的范围，RISC-V 显示 RV64GC 常见的 2/4 Byte，并不表示整体复杂度倍数。<a href="#x86-ref-S02">[S02]</a> <a href="#x86-ref-S03">[S03]</a> <a href="#x86-ref-S18">[S18]</a>'),
 '02':('fig02_x86_bytes.svg','<code>48 83 07 01</code> 在 GNU as / objdump（x86-64）中核对。标记了本例实际出现的编码字段；其他指令可以有更多字段。<a href="#x86-ref-S02">[S02]</a>'),
 '03':('fig03_frontend_paths.svg','高层功能路径。并非任何 Intel、AMD、Apple 或 RISC-V 实现的真实 RTL 框图；现代高性能核心的后端复杂性同样重要。<a href="#x86-ref-S10">[S10]</a>'),
 '04':('fig04_x86_timeline.svg','选取 8086、386、AMD64 与 x86S 的主要历史节点。为保证可读性，节点等间距排列，不按真实年份间隔缩放。<a href="#x86-ref-S16">[S16]</a> <a href="#x86-ref-S15">[S15]</a> <a href="#x86-ref-S05">[S05]</a>'),
 '05':('fig05_rd_spend.svg','数据来自 Intel 与 AMD 的 2025 年度 Form 10-K（单位：十亿美元）。这些是公司总研发费用，与 x86 历史兼容性专属研发费用不是同一个统计口径。<a href="#x86-ref-S07">[S07]</a> <a href="#x86-ref-S08">[S08]</a>'),
 '06':('fig06_decoder_power.svg','2016 年 CoolDC 论文估计，当 decoded-instruction cache 被突破时解码器占封装功耗约 3%–10%。不是现代芯片的通用范围，也不能据此计算换 ISA 的节能率。<a href="#x86-ref-S09">[S09]</a>'),
 '07':('fig07_migration_tasks.svg','根据微软与 Apple 官方迁移文档梳理工作类型；没有对成本、工期或难度编造数值。<a href="#x86-ref-S14">[S14]</a> <a href="#x86-ref-S11">[S11]</a>'),
}

for n,(name,caption) in CHARTS.items():
    markup=(ROOT/'assets'/name).read_text(encoding='utf-8').strip()
    wrapper=(f'<div class="v-figure v-chart-scroll">\n'
             f'<p class="v-scroll-hint">左右滑动查看完整图表；键盘聚焦后可用方向键。</p>\n'
             f'<div class="v-chart-viewport" tabindex="0" role="region" aria-label="第{int(n)}张科研图表">\n{markup}\n</div>\n'
             f'<p class="v-caption">图 {int(n)} · {caption}</p>\n</div>')
    needle=f'<!--FIG{n}-->'
    assert TEMPLATE.count(needle)==1,needle
    TEMPLATE=TEMPLATE.replace(needle,wrapper)
assert '<!--FIG' not in TEMPLATE
(ROOT/'article.md').write_text(TEMPLATE,encoding='utf-8')

SIMPLE=(ROOT/'reproduce'/'article_template.md').read_text(encoding='utf-8')
for n,(name,caption) in CHARTS.items():
    loc='/2026/11/03/why-x86-is-a-mess/assets/'+name.replace('.svg','.png')
    simple=f'![图 {int(n)} · 科研风格图表]({loc})\n\n*图 {int(n)}：{re.sub(r"<[^>]*>","",caption)}*'
    SIMPLE=SIMPLE.replace(f'<!--FIG{n}-->',simple)
(ROOT/'article_static.md').write_text(SIMPLE,encoding='utf-8')

manifest={'title':'为什么我觉得 X86 指令集 就是一坨狗屎','slug':'why-x86-is-a-mess','date':'2026-11-03','charts':list(CHARTS),'source_markers':len(set(re.findall(r'S\d\d',TEMPLATE))), 'total_chars':len(TEMPLATE),'files':[]}
for f in sorted(ROOT.rglob('*')):
    if f.is_file() and not f.name=='MANIFEST.json':
        manifest['files'].append({'path':str(f.relative_to(ROOT)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size})
(ROOT/'MANIFEST.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
print('built',ROOT/'article.md','chars',len(TEMPLATE))
